﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;
using System.Data.OleDb;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Excel.Workbook xlWorkBook;
            // Excel.Worksheet xlWorkSheet;
            object misValue = System.Reflection.Missing.Value;
            Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
            Microsoft.Office.Interop.Excel.Worksheet xlSheet1;
            Microsoft.Office.Interop.Excel.Sheets xlWorkSheets;

            string path = @"d:\\csharp-Excel.xls";
            xlApp = new Microsoft.Office.Interop.Excel.Application();
            xlApp.Visible = true;
            xlApp.DisplayAlerts = false;
            xlWorkBook = xlApp.Workbooks.Open(path, 0, false, 5, "", "", false, Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "", true, false, 0, true, false, false);
            //Get all the sheets in the workbook
            xlWorkSheets = xlWorkBook.Worksheets;
            //Get the allready exists sheet
            xlSheet1 = (Microsoft.Office.Interop.Excel.Worksheet)xlWorkSheets.get_Item("Sheet1");
            Microsoft.Office.Interop.Excel.Range range = xlSheet1.UsedRange;

            int _lastRow = xlSheet1.Range["A" + xlSheet1.Rows.Count].End[Excel.XlDirection.xlUp].Row;
            int _lastcol = xlSheet1.Range["A" + xlSheet1.Columns.Count].End[Excel.XlDirection.xlUp].Column;
            int flag = 0;
            for (int i = 2; i <= _lastRow; i++)
            {


                String str = Convert.ToString((range.Cells[i, 1] as Excel.Range).Value2);

                if (txtEmpId.Text == str)
                {
                    txtFName.Text = Convert.ToString((range.Cells[i, 2] as Excel.Range).Value2);
                    txtlName.Text = Convert.ToString((range.Cells[i, 3] as Excel.Range).Value2);
                    txtAdd.Text = Convert.ToString((range.Cells[i, 4] as Excel.Range).Value2);
                  //  datetimepicker1.text = convert.tostring((range.cells[i, 5] as excel.range).value2);//
                    txtCont.Text = Convert.ToString((range.Cells[i, 6] as Excel.Range).Value2);
                    comboBox1.Text = Convert.ToString((range.Cells[i, 7] as Excel.Range).Value2);
                    txtSal.Text = Convert.ToString((range.Cells[i, 8] as Excel.Range).Value2);
                    comboBox2.Text = Convert.ToString((range.Cells[i, 9] as Excel.Range).Value2);

                    flag = 1;
                    break;
                }

            }
            if (flag == 0)
            {
                MessageBox.Show("not found");
            }



            xlWorkBook.Close(true, misValue, misValue);


            xlSheet1 = null;
            xlWorkBook = null;
            xlApp.Quit();

            GC.WaitForPendingFinalizers();
            GC.Collect();
            GC.WaitForPendingFinalizers();
            GC.Collect();
        }

        private void txtEmpId_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Excel.Workbook xlWorkBook;
            // Excel.Worksheet xlWorkSheet;
            object misValue = System.Reflection.Missing.Value;
            Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
            Microsoft.Office.Interop.Excel.Worksheet xlSheet1;
            Microsoft.Office.Interop.Excel.Sheets xlWorkSheets;

            string path = @"d:\\csharp-Excel.xls";
            xlApp = new Microsoft.Office.Interop.Excel.Application();
            xlApp.Visible = true;
            xlApp.DisplayAlerts = false;
            xlWorkBook = xlApp.Workbooks.Open(path, 0, false, 5, "", "", false, Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "", true, false, 0, true, false, false);
            //Get all the sheets in the workbook
            xlWorkSheets = xlWorkBook.Worksheets;
            //Get the allready exists sheet
            xlSheet1 = (Microsoft.Office.Interop.Excel.Worksheet)xlWorkSheets.get_Item("Sheet1");
            Microsoft.Office.Interop.Excel.Range range = xlSheet1.UsedRange;

          
            txtEmpId.Text = Convert.ToString((range.Cells[2, 1] as Excel.Range).Value2);
            txtFName.Text = Convert.ToString((range.Cells[2, 2] as Excel.Range).Value2);
            txtlName.Text = Convert.ToString((range.Cells[2, 3] as Excel.Range).Value2);
            txtAdd.Text = Convert.ToString((range.Cells[2, 4] as Excel.Range).Value2);
          //  textBox9.Text = Convert.ToString((range.Cells[2, 5] as Excel.Range).Value2);//
            txtCont.Text = Convert.ToString((range.Cells[2, 6] as Excel.Range).Value2);
            comboBox1.Text = Convert.ToString((range.Cells[2, 7] as Excel.Range).Value2);
            txtSal.Text = Convert.ToString((range.Cells[2, 8] as Excel.Range).Value2);
            comboBox2.Text = Convert.ToString((range.Cells[2, 9] as Excel.Range).Value2);

         


            xlWorkBook.Close(true, misValue, misValue);


            xlSheet1 = null;
            xlWorkBook = null;
            xlApp.Quit();

            GC.WaitForPendingFinalizers();
            GC.Collect();
            GC.WaitForPendingFinalizers();
            GC.Collect();
        }
    }
}
