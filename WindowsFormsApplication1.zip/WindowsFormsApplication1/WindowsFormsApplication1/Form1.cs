﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using Excel = Microsoft.Office.Interop.Excel;


namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void txtEmpId_TextChanged(object sender, EventArgs e)
        {
            int employeeID;
            if (txtEmpId.Text != "" && int.TryParse(txtEmpId.Text, out employeeID) == false)
            {
                MessageBox.Show("Invalid input in employee ID");
                txtEmpId.Focus();
                return;
            }
            else if (txtEmpId.Text == "")
            {
                MessageBox.Show("enter input in employee ID");
                txtEmpId.Focus();
                return;
            }

        }

        private void txtFName_TextChanged(object sender, EventArgs e)
        {
            int firstname;
            if (txtFName.Text != "" && int.TryParse(txtFName.Text, out firstname) == true)
            {
                MessageBox.Show("Invalid input in employee first name");
                txtFName.Focus();
                return;
            }
            else if (txtFName.Text == "")
            {
                MessageBox.Show("enter input in employee first name");
                txtFName.Focus();
                return;
            }
　

        }

        private void txtLName_TextChanged(object sender, EventArgs e)
        {
            int lastname;
            if (txtLName.Text != "" && int.TryParse(txtLName.Text, out lastname) == true)
            {
                MessageBox.Show("Invalid input in employee last name");
                txtLName.Focus();
                return;
            }
            else if (txtLName.Text == "")
            {
                MessageBox.Show("enter input in employee last name");
                txtLName.Focus();
                return;
            }
        }

       

        private void txtCont_TextChanged(object sender, EventArgs e)
        {
            int contact;
            if (txtCont.Text.Length !=10 && int.TryParse(txtCont.Text, out contact) == false)
            {
                MessageBox.Show("Invalid input in contact");
                txtCont.Focus();
                return;
            }
            else if (txtCont.Text == "")
            {
                MessageBox.Show("enter input in employee contact");
                txtCont.Focus();
                return;
            }
            

        }


        private void comboboxDesig_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboboxDesig.SelectedIndex == -1)
            {
                MessageBox.Show("Please select Designation !");
                return;

            }
        }

        private void txtAdd_TextChanged(object sender, EventArgs e)
        {
            if(txtAdd.Text == string.Empty)
            {
                MessageBox.Show("Please enter Address!");
                return;
            }

        }

        private void txtSal_TextChanged(object sender, EventArgs e)
        {
            if (txtSal.Text == string.Empty || !System.Text.RegularExpressions.Regex.IsMatch(txtSal.Text, @"^((\+){0,1}91(\s){0,1}(\-){0,1}(\s){0,1}){0,1}9[0-9](\s){0,1}(\-){0,1}(\s){0,1}[1-9]{1}[0-9]{7}$"))
            {
                MessageBox.Show("Please enter valid Salary!");
                return;
            }

        }

        private void dateTimePicker_ValueChanged(object sender, EventArgs e)
        {
            if (dateTimePicker.Value.ToString() == "")
            {
                MessageBox.Show("Please select date!");
                dateTimePicker.Focus();
                return;
            }
        }

        private void comboBoxDepartment_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBoxDepartment.SelectedIndex == -1)
            {
                MessageBox.Show("Please select Department !");
                return;

            }

        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            Excel.Workbook xlWorkBook;
            Excel.Worksheet xlWorkSheet;
            object misValue = System.Reflection.Missing.Value;
            Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
             Microsoft.Office.Interop.Excel.Worksheet xlSheet1;
            Microsoft.Office.Interop.Excel.Sheets xlWorkSheets;

            if (xlApp == null)
            {
                MessageBox.Show("Excel is not properly installed!!");
                return;
            }
            if (!System.IO.File.Exists(@"d:\\nasrin.xlsx"))
            {
                xlWorkBook = xlApp.Workbooks.Add(misValue);

                xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);
                xlWorkSheet.Cells[1, 1] = "Employee ID";
                xlWorkSheet.Cells[1, 2] = "First Name";
                xlWorkSheet.Cells[1, 3] = "Last Name";
                xlWorkSheet.Cells[1, 4] = "Address";
                xlWorkSheet.Cells[1, 5] = "Date of Birth";
                xlWorkSheet.Cells[1, 6] = "Contact";
                xlWorkSheet.Cells[1, 7] = "Designation";
                xlWorkSheet.Cells[1, 8] = "Salary";
                xlWorkSheet.Cells[1, 9] = "Department";

                   int _lastRow = xlWorkSheet.Range["A" + xlWorkSheet.Rows.Count].End[Excel.XlDirection.xlUp].Row + 1;

                xlWorkSheet.Cells[_lastRow, 1] = txtEmpId.Text;
                xlWorkSheet.Cells[_lastRow, 2] = txtFName.Text;
                xlWorkSheet.Cells[_lastRow, 3] = txtLName.Text;
                xlWorkSheet.Cells[_lastRow, 4] = txtAdd.Text;
                xlWorkSheet.Cells[_lastRow, 5] = dateTimePicker.Value.ToString("yyyy-MM-dd");;
                xlWorkSheet.Cells[_lastRow, 6] = txtCont.Text;

                xlWorkSheet.Cells[_lastRow, 7] = this.comboboxDesig.GetItemText(this.comboboxDesig.SelectedItem); 
                xlWorkSheet.Cells[_lastRow, 8] = txtSal.Text;
                xlWorkSheet.Cells[_lastRow, 9] = this.comboBoxDepartment.GetItemText(this.comboBoxDepartment.SelectedItem); 
                xlWorkBook.SaveAs("d:\\nasrin.xlsx", Excel.XlFileFormat.xlWorkbookNormal, misValue, misValue, misValue, misValue, Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
                xlWorkBook.Close(true, misValue, misValue);
                MessageBox.Show("Data is saved to the excel file , you can find the file d:\\nasrin.xlsx");
                xlApp.Quit();
                Marshal.ReleaseComObject(xlWorkSheet);
                Marshal.ReleaseComObject(xlWorkBook);
                Marshal.ReleaseComObject(xlApp);
            }
            else
            {

                string path = @"d:\\nasrin.xlsx";
                 xlApp = new Microsoft.Office.Interop.Excel.Application();
                 xlApp.Visible = true;
                 xlApp.DisplayAlerts = false;
                 xlWorkBook = xlApp.Workbooks.Open(path, 0, false, 5, "", "", false, Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "", true, false, 0, true, false, false);
                                //Get all the sheets in the workbook
                 xlWorkSheets = xlWorkBook.Worksheets;
                                //Get the allready exists sheet
                 xlSheet1 = (Microsoft.Office.Interop.Excel.Worksheet)xlWorkSheets.get_Item("Sheet1");
                 Microsoft.Office.Interop.Excel.Range range = xlSheet1.UsedRange;

                 int _lastRow = xlSheet1.Range["A" + xlSheet1.Rows.Count].End[Excel.XlDirection.xlUp].Row + 1;
                 int flag = 0;
              
                 for (int i = 2; i <= _lastRow;i++ )
                 {
                    

                    String str = Convert.ToString((range.Cells[i, 1] as Excel.Range).Value2);
                   
                    if(txtEmpId.Text==str)
                    {
                       
                        flag = 1;
                    }

                 }
                 MessageBox.Show("out for");
                 if (flag == 0)
                 {

                     xlSheet1.Cells[_lastRow, 1] = txtEmpId.Text;
                     xlSheet1.Cells[_lastRow, 2] = txtFName.Text;
                     xlSheet1.Cells[_lastRow, 3] = txtLName.Text;
                     xlSheet1.Cells[_lastRow, 4] = txtAdd.Text;
                     xlSheet1.Cells[_lastRow, 5] = dateTimePicker.Value.ToString("yyyy-MM-dd"); ;
                     xlSheet1.Cells[_lastRow, 6] = txtCont.Text;

                     xlSheet1.Cells[_lastRow, 7] = this.comboboxDesig.GetItemText(this.comboboxDesig.SelectedItem);
                     xlSheet1.Cells[_lastRow, 8] = txtSal.Text;
                     xlSheet1.Cells[_lastRow, 9] = this.comboBoxDepartment.GetItemText(this.comboBoxDepartment.SelectedItem);
                     xlWorkBook.SaveAs("d:\\nasrin.xlsx", Excel.XlFileFormat.xlWorkbookNormal, misValue, misValue, misValue, misValue, Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
                     xlWorkBook.Close(true, misValue, misValue);
                     MessageBox.Show("Data is saved to the excel file , you can find the file d:\\nasrin.xlsx");
                 }
                 else
                 {
                     MessageBox.Show("Employee Id is alerady present");
                 }
                     xlSheet1 = null;
                     xlWorkBook = null;
                     xlApp.Quit();
                 
                GC.WaitForPendingFinalizers();
                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
            }

        private void btnClose_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are You Sure To Exit Programme ?", "Exit", MessageBoxButtons.OKCancel) == DialogResult.OK)
            {
                Application.Exit();
            }
        }

        private void btnRes_Click(object sender, EventArgs e)
        {
            ClearSpace(this); 
        }
        public static void ClearSpace(Control control)
        {
            foreach (Control c in control.Controls)
            {
                var textBox = c as TextBox;
                var comboBox = c as ComboBox;

                if (textBox != null)
                    (textBox).Clear();

                if (comboBox != null)
                    comboBox.SelectedIndex = -1;

                if (c.HasChildren)
                    ClearSpace(c);
            }
        }

        }
}
